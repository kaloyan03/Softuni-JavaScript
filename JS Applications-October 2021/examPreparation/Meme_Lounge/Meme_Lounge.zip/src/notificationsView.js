import { html } from '../node_modules/lit-html/lit-html.js';

const notificationsViewTemplate = () => html`
<!-- Notifications -->
<section id="notifications">
    <div id="errorBox" class="notification">
        <span>MESSAGE</span>
    </div>
</section>
`